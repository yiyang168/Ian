/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1_3306
Source Server Version : 80011
Source Host           : 127.0.0.1:3306
Source Database       : gems

Target Server Type    : MYSQL
Target Server Version : 80011
File Encoding         : 65001

Date: 2020-05-16 21:50:44
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for db_company
-- ----------------------------
DROP TABLE IF EXISTS `db_company`;
CREATE TABLE `db_company` (
  `id` varchar(32) NOT NULL,
  `companyID` int(6) NOT NULL AUTO_INCREMENT,
  `companyName` varchar(50) NOT NULL,
  `power` int(3) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `sex` varchar(5) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `userName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `question1` varchar(50) NOT NULL,
  `answer1` varchar(50) NOT NULL,
  `question2` varchar(50) NOT NULL,
  `answer2` varchar(50) NOT NULL,
  `hrPhone` varchar(50) DEFAULT NULL,
  `nation` varchar(50) DEFAULT NULL,
  `year` varchar(50) DEFAULT NULL,
  `month` varchar(50) DEFAULT NULL,
  `day` varchar(50) DEFAULT NULL,
  `hrProvince` varchar(50) DEFAULT NULL,
  `hrCity` varchar(50) DEFAULT NULL,
  `hrEmail` varchar(50) DEFAULT NULL,
  `scale` varchar(50) DEFAULT NULL,
  `buildTime` varchar(50) DEFAULT NULL,
  `companyListing` varchar(50) DEFAULT NULL,
  `buildMoney` varchar(50) DEFAULT NULL,
  `companyPhone` varchar(50) DEFAULT NULL,
  `mianBusiness` varchar(500) DEFAULT NULL,
  `companyRemarks` varchar(500) DEFAULT NULL,
  `img1` varchar(100) DEFAULT NULL,
  `img2` varchar(100) DEFAULT NULL,
  `img3` varchar(100) DEFAULT NULL,
  `img4` varchar(100) DEFAULT NULL,
  `welfare` varchar(200) DEFAULT NULL,
  `file` varchar(100) DEFAULT NULL,
  `lng` varchar(50) DEFAULT NULL,
  `lat` varchar(50) DEFAULT NULL,
  `companyAddress` varchar(100) DEFAULT NULL,
  `choiceQuestion` int(5) DEFAULT NULL,
  `judgementQuestion` int(5) DEFAULT NULL,
  PRIMARY KEY (`companyID`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10043 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of db_company
-- ----------------------------
INSERT INTO `db_company` VALUES ('acdc54b788274851b30742d9439ecc4c', '10042', '东华', '1', '侯威', '男', null, 'dh', '123456', '您的初中老师名字是？', '耿老师', '您留恋的地方是？', '单位', '13598111095', '0', '1968', '10', '5', '河南省', '郑州市', '2224704486@qq.com', '大型', '2000-01-01', '2010-01-01', '10000', '13598111096', '代码编程', '待遇优厚', 'b6bdd943103e4cc1bb58079c1b950b5f.jpg', 'f7a2f6a89a714473ba08faad42790441.jpg', '6c32039f76374d26b53e06a137d6691c.jpg', '0575a47a95744fcd9e5d9942e220c0b9.jpg', '包吃 包住 餐补 房补 ', '4218610acebe478dada4268cbfc1a839.docx', '113.663863', '34.813183', '河南省郑州市金水区', '1', '1');

-- ----------------------------
-- Table structure for db_exam
-- ----------------------------
DROP TABLE IF EXISTS `db_exam`;
CREATE TABLE `db_exam` (
  `id` varchar(32) NOT NULL,
  `companyID` int(6) DEFAULT NULL,
  `examType` varchar(50) DEFAULT NULL,
  `question` varchar(300) DEFAULT NULL,
  `miss1` varchar(300) DEFAULT NULL,
  `miss2` varchar(300) DEFAULT NULL,
  `miss3` varchar(300) DEFAULT NULL,
  `right` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of db_exam
-- ----------------------------
INSERT INTO `db_exam` VALUES ('d7cda0357b134280b05cf0c594872f38', '10042', '选择题', '1+1=?', '0', '1', '3', '2');
INSERT INTO `db_exam` VALUES ('f1c0d29cb0c8425685ad58f4421985cf', '10042', '判断题', '2+2=4', '0', null, null, '1');

-- ----------------------------
-- Table structure for db_job
-- ----------------------------
DROP TABLE IF EXISTS `db_job`;
CREATE TABLE `db_job` (
  `id` varchar(32) NOT NULL,
  `jobID` int(6) NOT NULL AUTO_INCREMENT,
  `companyID` int(6) NOT NULL,
  `jobName` varchar(100) NOT NULL,
  `jobRemarks` varchar(300) DEFAULT NULL,
  `needPeople` int(6) DEFAULT NULL,
  `jobSalary1` varchar(20) DEFAULT NULL,
  `jobSalary2` varchar(20) DEFAULT NULL,
  `jobSalary3` varchar(20) DEFAULT NULL,
  `degree` varchar(50) DEFAULT NULL,
  `jobExperience` varchar(50) DEFAULT NULL,
  `jobType` varchar(50) DEFAULT NULL,
  `jobDescribe` varchar(500) DEFAULT NULL,
  `look` int(6) DEFAULT NULL,
  `signup` int(6) DEFAULT NULL,
  `examine` int(2) DEFAULT NULL,
  `examineTime` varchar(30) DEFAULT NULL,
  `delete` int(2) DEFAULT NULL,
  `deleteTime` datetime DEFAULT NULL,
  PRIMARY KEY (`jobID`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10028 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of db_job
-- ----------------------------
INSERT INTO `db_job` VALUES ('a841893ee2b94daca1333dedc41979cf', '10027', '10042', '开发工程师', '前台开发', '1', '4000', '5000', null, '本科含本科以上', '不需要经验', '全职', '代码编写', '0', '1', '1', '2020-05-16 21:35:29', '0', null);

-- ----------------------------
-- Table structure for db_offer
-- ----------------------------
DROP TABLE IF EXISTS `db_offer`;
CREATE TABLE `db_offer` (
  `id` varchar(32) NOT NULL,
  `offerID` int(6) NOT NULL AUTO_INCREMENT,
  `studentID` int(6) DEFAULT NULL,
  `jobID` int(6) DEFAULT NULL,
  `companyID` int(6) DEFAULT NULL,
  `exam` int(6) DEFAULT NULL,
  `pass` int(6) DEFAULT NULL,
  `examScore` int(6) DEFAULT NULL,
  `workFile` varchar(50) DEFAULT NULL,
  `file` varchar(50) DEFAULT NULL,
  `contact` int(1) DEFAULT NULL,
  `delete` int(11) NOT NULL,
  `deleteTime` datetime DEFAULT NULL,
  `buildTime` datetime DEFAULT NULL,
  PRIMARY KEY (`offerID`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='根据学生id，查看学生信息，保存学生简历地址，是否已联系，删除\r\npass 是否被录用\r\nexam 是否已参加考核\r\nexamScore 考核分数\r\nfile 学生简历\r\nworkFile 公司就业协议';

-- ----------------------------
-- Records of db_offer
-- ----------------------------
INSERT INTO `db_offer` VALUES ('7c6e7ecf2fc04de6b6b725d3b187cc2b', '31', '307045', '10027', '10042', '1', '2', '100', '4218610acebe478dada4268cbfc1a839.docx', 'a31bc63aa2ca44d5b0495c90eca0fa64.docx', '0', '0', null, '2020-05-16 21:35:48');

-- ----------------------------
-- Table structure for db_student
-- ----------------------------
DROP TABLE IF EXISTS `db_student`;
CREATE TABLE `db_student` (
  `id` varchar(32) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `power` int(3) NOT NULL,
  `studentID` int(6) NOT NULL,
  `name` varchar(50) NOT NULL,
  `sex` varchar(5) NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `question1` varchar(50) NOT NULL,
  `answer1` varchar(50) NOT NULL,
  `question2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `answer2` varchar(50) DEFAULT NULL,
  `nation` varchar(50) DEFAULT NULL,
  `year` varchar(50) DEFAULT NULL,
  `month` varchar(50) DEFAULT NULL,
  `day` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province2` varchar(50) DEFAULT NULL,
  `city2` varchar(50) DEFAULT NULL,
  `marry` varchar(10) DEFAULT NULL,
  `politicalStatus` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `start` varchar(50) DEFAULT NULL,
  `end` varchar(50) DEFAULT NULL,
  `education` varchar(50) DEFAULT NULL,
  `degree` varchar(50) DEFAULT NULL,
  `english` varchar(50) DEFAULT NULL,
  `grade` int(6) DEFAULT NULL,
  `cadre` varchar(20) DEFAULT NULL,
  `job` varchar(50) DEFAULT NULL,
  `ranking` varchar(50) DEFAULT NULL,
  `mianCourse` varchar(50) DEFAULT NULL,
  `intention` varchar(50) DEFAULT NULL,
  `province3` varchar(50) DEFAULT NULL,
  `city3` varchar(50) DEFAULT NULL,
  `salary` varchar(50) DEFAULT NULL,
  `companyName` varchar(50) DEFAULT NULL,
  `companyType` varchar(50) DEFAULT NULL,
  `work` varchar(50) DEFAULT NULL,
  `jobNature` varchar(50) DEFAULT NULL,
  `startWork` varchar(50) DEFAULT NULL,
  `endWork` varchar(50) DEFAULT NULL,
  `workContent` varchar(200) DEFAULT NULL,
  `companyName2` varchar(50) DEFAULT NULL,
  `companyType2` varchar(50) DEFAULT NULL,
  `work2` varchar(50) DEFAULT NULL,
  `jobNature2` varchar(50) DEFAULT NULL,
  `startWork2` varchar(50) DEFAULT NULL,
  `endWork2` varchar(50) DEFAULT NULL,
  `workContent2` varchar(200) DEFAULT NULL,
  `companyName3` varchar(50) DEFAULT NULL,
  `companyType3` varchar(50) DEFAULT NULL,
  `work3` varchar(50) DEFAULT NULL,
  `jobNature3` varchar(50) DEFAULT NULL,
  `startWork3` varchar(50) DEFAULT NULL,
  `endWork3` varchar(50) DEFAULT NULL,
  `workContent3` varchar(200) DEFAULT NULL,
  `merit` varchar(300) DEFAULT NULL,
  `self` varchar(300) DEFAULT NULL,
  `fileAddress` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`,`power`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of db_student
-- ----------------------------
INSERT INTO `db_student` VALUES ('67496ecacbca43b6ae321b1ee2e34383', 'cz', '654321', '0', '307045', '陈卓', '男', '13353635879', '您的小学老师名字是？', '高老师', '您留恋的地方是？', '学校', '0', '1996', '3', '6', '河南省', '安阳市', '河南省', '安阳市', '未婚', '共青团员', '949721553@qq.com', '2016-09-01', '2020-06-30', '本科', '学士', '大学英语四级 (CET4)', '536', '是', '心理委员', '前5%', 'Java编程', '全职', '河南省', '郑州市', '4000元以上', '东华', '计算机软件', '工程师', '实习', '2019-10-01', '2020-01-15', '后台开发', null, null, null, '全职', null, null, null, null, null, null, '全职', null, null, null, '校三等奖学金', '热情开朗', 'a31bc63aa2ca44d5b0495c90eca0fa64.docx');

-- ----------------------------
-- Table structure for db_teacher
-- ----------------------------
DROP TABLE IF EXISTS `db_teacher`;
CREATE TABLE `db_teacher` (
  `id` varchar(32) NOT NULL,
  `teacherID` int(6) NOT NULL AUTO_INCREMENT,
  `power` int(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `userName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `question1` varchar(50) NOT NULL,
  `answer1` varchar(50) NOT NULL,
  `question2` varchar(50) NOT NULL,
  `answer2` varchar(50) NOT NULL,
  PRIMARY KEY (`teacherID`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1201643071 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of db_teacher
-- ----------------------------
INSERT INTO `db_teacher` VALUES ('bdd31d07d0da45c696709bd4e6ec2d8b', '199636', '2', '马洁', '女', '15896816022', 'mj', '123456', '您的高中老师名字是？', '张老师', '您最喜欢的歌手是？', '周杰伦');
